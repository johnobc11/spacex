# SpaceX App

This is a create React application that consumes data from the SpaceX public API. The application retrieves historic and future SpaceX launches and presents them in a list view.

The API documentation is available from:
Postman - [https://docs.spacexdata.com](https://docs.spacexdata.com/)
GitHub - [https://github.com/r-spacex/SpaceX-API](https://github.com/r-spacex/SpaceX-API)
